#include "ch32v00x.h"
#include <stdlib.h>

// GPIO Configuration magic numbers
#define PIN_IN_FLOAT 0x4
#define PIN_OUT_PP 0x3

// Dice faces bitmap mapping (Bit 0 = D1 ... Bit 6 = D7)
const uint8_t DICE_FACES[7] = {
    0x00,  // 0: All OFF
    0xC0,  // 1: D7
    0x0C,  // 2: D4, D3
    0xCC,  // 3: D4, D7, D3
    0x0F,  // 4: D4, D6, D, D3
    0xCF,  // 5: D4, D2, D7, D1, D3
    0x3F   // 6: D4, D6, D2, D1, D5, D3
};

volatile uint8_t button_pressed_flag = 0;

void EXTI7_0_IRQHandler (void) __attribute__ ((interrupt ("WCH-Interrupt-fast")));

void EXTI7_0_IRQHandler (void) {
    if (EXTI_GetITStatus (EXTI_Line2) != RESET) {
        button_pressed_flag = 1;
        EXTI_ClearITPendingBit (EXTI_Line2);
    }
}

// UPDATED: Button is now on PA2
void setup_button_interrupt (void) {
    RCC_APB2PeriphClockCmd (RCC_APB2Periph_GPIOA | RCC_APB2Periph_AFIO, ENABLE);

    // Configure PA2 as Input with Internal Pull-Up
    GPIOA->CFGLR &= ~(0xF << 8);
    GPIOA->CFGLR |= (0x8 << 8);
    GPIOA->OUTDR |= (1 << 2);

    EXTI_InitTypeDef EXTI_InitStructure = {0};
    NVIC_InitTypeDef NVIC_InitStructure = {0};

    // Tell AFIO to map EXTI Line 2 to GPIO Port A
    GPIO_EXTILineConfig (GPIO_PortSourceGPIOA, GPIO_PinSource2);

    EXTI_InitStructure.EXTI_Line = EXTI_Line2;
    EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;
    EXTI_InitStructure.EXTI_LineCmd = ENABLE;
    EXTI_Init (&EXTI_InitStructure);

    NVIC_InitStructure.NVIC_IRQChannel = EXTI7_0_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init (&NVIC_InitStructure);
}

// UPDATED: PC4 and PC1 have been completely swapped
void set_led (uint8_t led) {
    // Reset PA1 (bits 4-7) to Input Floating
    GPIOA->CFGLR = (GPIOA->CFGLR & ~(0xF << 4)) | (0x4 << 4);
    // Reset PC1 (bits 4-7), PC2 (bits 8-11), and PC4 (bits 16-19) to Input Floating
    GPIOC->CFGLR = (GPIOC->CFGLR & ~((0xF << 4) | (0xF << 8) | (0xF << 16))) | ((0x4 << 4) | (0x4 << 8) | (0x4 << 16));

    switch (led) {
    case 5:  // D1: PC2(+), PC4(-) -> swapped from PC1
        GPIOC->BSHR = (1 << 2);
        GPIOC->BCR = (1 << 4);
        GPIOC->CFGLR = (GPIOC->CFGLR & ~((0xF << 8) | (0xF << 16))) | ((PIN_OUT_PP << 8) | (PIN_OUT_PP << 16));
        break;
    case 6:  // D2: PC4(+), PC2(-) -> swapped from PC1
        GPIOC->BSHR = (1 << 4);
        GPIOC->BCR = (1 << 2);
        GPIOC->CFGLR = (GPIOC->CFGLR & ~((0xF << 16) | (0xF << 8))) | ((PIN_OUT_PP << 16) | (PIN_OUT_PP << 8));
        break;
    case 3:  // D3: PC2(+), PA1(-) (Unchanged)
        GPIOC->BSHR = (1 << 2);
        GPIOA->BCR = (1 << 1);
        GPIOC->CFGLR = (GPIOC->CFGLR & ~(0xF << 8)) | (PIN_OUT_PP << 8);
        GPIOA->CFGLR = (GPIOA->CFGLR & ~(0xF << 4)) | (PIN_OUT_PP << 4);
        break;
    case 4:  // D4: PA1(+), PC2(-) (Unchanged)
        GPIOA->BSHR = (1 << 1);
        GPIOC->BCR = (1 << 2);
        GPIOA->CFGLR = (GPIOA->CFGLR & ~(0xF << 4)) | (PIN_OUT_PP << 4);
        GPIOC->CFGLR = (GPIOC->CFGLR & ~(0xF << 8)) | (PIN_OUT_PP << 8);
        break;
    case 1:  // D5: PC4(+), PA1(-) -> swapped from PC1
        GPIOC->BSHR = (1 << 4);
        GPIOA->BCR = (1 << 1);
        GPIOC->CFGLR = (GPIOC->CFGLR & ~(0xF << 16)) | (PIN_OUT_PP << 16);
        GPIOA->CFGLR = (GPIOA->CFGLR & ~(0xF << 4)) | (PIN_OUT_PP << 4);
        break;
    case 2:  // D6: PA1(+), PC4(-) -> swapped from PC1
        GPIOA->BSHR = (1 << 1);
        GPIOC->BCR = (1 << 4);
        GPIOA->CFGLR = (GPIOA->CFGLR & ~(0xF << 4)) | (PIN_OUT_PP << 4);
        GPIOC->CFGLR = (GPIOC->CFGLR & ~(0xF << 16)) | (PIN_OUT_PP << 16);
        break;
    case 7:  // D7: PC1(+), PC2(-) PA1(-) -> swapped from PC4
        GPIOC->BSHR = (1 << 1);
        GPIOC->BCR = (1 << 2);
        GPIOC->CFGLR = (GPIOC->CFGLR & ~(0xF << 4)) | (PIN_OUT_PP << 4);
        GPIOC->CFGLR = (GPIOC->CFGLR & ~(0xF << 8)) | (PIN_OUT_PP << 8);
        // GPIOA->CFGLR = (GPIOA->CFGLR & ~(0xF << 4)) | (PIN_OUT_PP << 4);
        break;
            case 8:  // D7: PC1(+), PC2(-) PA1(-) -> swapped from PC4
        GPIOC->BSHR = (1 << 2);
        GPIOC->BCR = (1 << 1);
        GPIOC->CFGLR = (GPIOC->CFGLR & ~(0xF << 4)) | (PIN_OUT_PP << 4);
        GPIOC->CFGLR = (GPIOC->CFGLR & ~(0xF << 8)) | (PIN_OUT_PP << 8);
        // GPIOA->CFGLR = (GPIOA->CFGLR & ~(0xF << 4)) | (PIN_OUT_PP << 4);
        break;
    }
}

void display_face (uint8_t face_value, uint32_t duration_ms) {
    uint8_t mask = DICE_FACES[face_value];
    uint8_t leds_on = 0;

    for (int i = 0; i < 8; i++) {
        if (mask & (1 << i))
            leds_on++;
    }

    if (leds_on == 0)
        return;

    uint32_t cycles = duration_ms / leds_on;

    for (uint32_t t = 0; t < cycles; t++) {
        for (int i = 0; i < 8; i++) {
            if (mask & (1 << i)) {
                set_led (i + 1);
                Delay_Ms (1);
                set_led (0);
            }
        }
    }
}

uint8_t play_roll_animation (void) {
    int delay = 10;
    uint8_t current_face = 1;

    for (int i = 0; i < 30; i++) {
        current_face = (rand() % 6) + 1;
        display_face (current_face, delay);
        delay += 5;
    }
    return current_face;
}

int main (void) {
    SystemInit();
    NVIC_PriorityGroupConfig (NVIC_PriorityGroup_1);
    SystemCoreClockUpdate();
    Delay_Init();

    RCC_APB2PeriphClockCmd (RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOC, ENABLE);
    RCC_APB1PeriphClockCmd (RCC_APB1Periph_PWR, ENABLE);

    // Disable remap so PA1/PA2 work as normal GPIO
    GPIO_PinRemapConfig(AFIO_PCFR1_PA12_REMAP, DISABLE);

    set_led (0);
    setup_button_interrupt();

    while (1) {
        set_led (0);
        button_pressed_flag = 0;

            PWR_EnterSTANDBYMode(PWR_STANDBYEntry_WFE);
        
        SystemInit();
        SystemCoreClockUpdate();
        Delay_Init();

        if (button_pressed_flag == 1) {

            static uint32_t entropy_pool = 12345;
            uint32_t press_time = 0;

            // UPDATED: Now checking GPIOA bit 2 instead of GPIOC
            if ((GPIOA->INDR & (1 << 2)) == 1) {
                press_time++;
                Delay_Ms (1);
            }

            entropy_pool += (press_time + SysTick->CNT);
            srand (entropy_pool);

            // RNG warm-up to ensure perfect randomness
            for (int i = 0; i < (press_time % 10); i++) {
                rand();
            }

            uint8_t final_result = play_roll_animation();
            display_face (final_result, 2000);

            button_pressed_flag = 0;
        }
    }
}