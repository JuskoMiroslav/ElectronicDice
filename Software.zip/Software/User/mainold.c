#include "ch32v00x.h"
#include <stdlib.h>

// GPIO Configuration magic numbers
#define PIN_IN_FLOAT 0x4  
#define PIN_OUT_PP   0x3  

// Dice faces bitmap mapping (Bit 0 = D1 ... Bit 6 = D7)
const uint8_t DICE_FACES[7] = {
    0x00, // 0: All OFF
    0x40, // 1: D7
    0x0C, // 2: D4, D3 
    0x4C, // 3: D4, D7, D3
    0x0F, // 4: D4, D2, D1, D3
    0x4F, // 5: D4, D2, D7, D1, D3
    0x3F  // 6: D4, D6, D2, D1, D5, D3
};

// Global flag set by the interrupt
volatile uint8_t button_pressed_flag = 0;

// Interrupt Handler for EXTI Lines 0 to 7
void EXTI7_0_IRQHandler(void) __attribute__((interrupt("WCH-Interrupt-fast")));
void EXTI7_0_IRQHandler(void) {
    if (EXTI_GetITStatus(EXTI_Line2) != RESET) {
        button_pressed_flag = 1; // Tell the main loop to roll the dice
        EXTI_ClearITPendingBit(EXTI_Line2); // Clear the flag so it doesn't loop forever
    }
}

// Your working SPL button and interrupt setup
void setup_button_interrupt(void) {
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC | RCC_APB2Periph_AFIO, ENABLE);

    // Configure PC2 as Input with Internal Pull-Up
    GPIOC->CFGLR &= ~(0xF << 8);  
    GPIOC->CFGLR |= (0x8 << 8);   
    GPIOC->OUTDR |= (1 << 2);     

    EXTI_InitTypeDef EXTI_InitStructure = {0};
    NVIC_InitTypeDef NVIC_InitStructure = {0};
    
    GPIO_EXTILineConfig(GPIO_PortSourceGPIOC, GPIO_PinSource2);
    
    EXTI_InitStructure.EXTI_Line = EXTI_Line2;
    EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;
    EXTI_InitStructure.EXTI_LineCmd = ENABLE;
    EXTI_Init(&EXTI_InitStructure);

    NVIC_InitStructure.NVIC_IRQChannel = EXTI7_0_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
}

// Turn on a single LED (1-7), or turn all off (0)
void set_led(uint8_t led) {
    // Reset all used pins to Input Floating
    GPIOA->CFGLR = (GPIOA->CFGLR & ~(0xFF << 4)) | (0x44 << 4);
    GPIOC->CFGLR = (GPIOC->CFGLR & ~((0xF << 4) | (0xF << 16))) | ((0x4 << 4) | (0x4 << 16));

    switch(led) {
        case 1: 
            GPIOA->BSHR = (1 << 2); GPIOC->BCR = (1 << 1);
            GPIOA->CFGLR = (GPIOA->CFGLR & ~(0xF << 8)) | (PIN_OUT_PP << 8);
            GPIOC->CFGLR = (GPIOC->CFGLR & ~(0xF << 4)) | (PIN_OUT_PP << 4);
            break;
        case 2: 
            GPIOC->BSHR = (1 << 1); GPIOA->BCR = (1 << 2);
            GPIOC->CFGLR = (GPIOC->CFGLR & ~(0xF << 4)) | (PIN_OUT_PP << 4);
            GPIOA->CFGLR = (GPIOA->CFGLR & ~(0xF << 8)) | (PIN_OUT_PP << 8);
            break;
        case 3: 
            GPIOA->BSHR = (1 << 2); GPIOA->BCR = (1 << 1);
            GPIOA->CFGLR = (GPIOA->CFGLR & ~(0xFF << 4)) | ((PIN_OUT_PP << 4) | (PIN_OUT_PP << 0)) << 4; 
            break;
        case 4: 
            GPIOA->BSHR = (1 << 1); GPIOA->BCR = (1 << 2);
            GPIOA->CFGLR = (GPIOA->CFGLR & ~(0xFF << 4)) | ((PIN_OUT_PP << 4) | (PIN_OUT_PP << 0)) << 4;
            break;
        case 5: 
            GPIOC->BSHR = (1 << 1); GPIOA->BCR = (1 << 1);
            GPIOC->CFGLR = (GPIOC->CFGLR & ~(0xF << 4)) | (PIN_OUT_PP << 4);
            GPIOA->CFGLR = (GPIOA->CFGLR & ~(0xF << 4)) | (PIN_OUT_PP << 4);
            break;
        case 6: 
            GPIOA->BSHR = (1 << 1); GPIOC->BCR = (1 << 1);
            GPIOA->CFGLR = (GPIOA->CFGLR & ~(0xF << 4)) | (PIN_OUT_PP << 4);
            GPIOC->CFGLR = (GPIOC->CFGLR & ~(0xF << 4)) | (PIN_OUT_PP << 4);
            break;
        case 7: 
            GPIOC->BSHR = (1 << 4); GPIOA->BCR = (1 << 1);
            GPIOC->CFGLR = (GPIOC->CFGLR & ~(0xF << 16)) | (PIN_OUT_PP << 16);
            GPIOA->CFGLR = (GPIOA->CFGLR & ~(0xF << 4)) | (PIN_OUT_PP << 4);
            break;
    }
}

// Accurately display a face for a specific duration
void display_face(uint8_t face_value, uint32_t duration_ms) {
    uint8_t mask = DICE_FACES[face_value];
    uint8_t leds_on = 0;
    
    for (int i = 0; i < 7; i++) {
        if (mask & (1 << i)) leds_on++;
    }
    
    if (leds_on == 0) return; 
    
    uint32_t cycles = duration_ms / leds_on; 
    
    for (uint32_t t = 0; t < cycles; t++) {
        for (int i = 0; i < 7; i++) {
            if (mask & (1 << i)) {
                set_led(i + 1);    
                Delay_Ms(1);       
                set_led(0);        
            }
        }
    }
}

// Animation loop
uint8_t play_roll_animation(void) {
    int delay = 10;
    uint8_t current_face = 1;
    
    for (int i = 0; i < 15; i++) {
        current_face = (rand() % 6) + 1; 
        display_face(current_face, delay);
        delay += 5; 
    }
    return current_face; 
}

int main(void) {
    // 1. System Initializations
    SystemInit();
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_1);
    SystemCoreClockUpdate();
    Delay_Init();
    
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOC, ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_PWR, ENABLE); // Required for STOP mode
    
    // Disable remap to free up PA1/PA2 for your LEDs
    GPIO_PinRemapConfig(AFIO_PCFR1_PA12_REMAP, DISABLE);

    // 2. Setup Peripherals
    set_led(0);      
    setup_button_interrupt();  

    uint32_t random_seed;

    while(1) {
        // --- DEEP SLEEP (STOP MODE) ---
        set_led(0); // Ensure LEDs are off to save power
        button_pressed_flag = 0; 
        
        // Use the SPL function for entering Stop Mode safely
    PWR_EnterSTANDBYMode(PWR_STANDBYEntry_WFE);
        
        // --- MCU WAKES UP HERE ---
        // Recover the clock back to 48MHz (Stop mode switches it to 8MHz internal)
        SystemInit();
        SystemCoreClockUpdate();
        Delay_Init();

// Skontrolujeme, ?i sme sa zobudili kv?li tla?idlu
        if (button_pressed_flag == 1) {
            
            // Statick�� premenn�� si pam?t�� svoju hodnotu aj po?as sp��nku,
            // preto?e SRAM pam?? je v STOP m��de st��le nap��jan��.
            static uint32_t entropy_pool = 12345; 
            uint32_t press_time = 0;
            
            // Po?��tame d??ku aktu��lneho stla?enia
            while ((GPIOC->INDR & (1 << 2)) == 0) {
                press_time++;
                Delay_Ms(1);
            }
            
            // Namie?ame dokonal? kokteil n��hodnosti: 
            // Historick? stav + aktu��lna d??ka stla?enia + aktu��lny tik procesora
            entropy_pool += (press_time + SysTick->CNT);
            
            // Nastav��me gener��tor
            srand(entropy_pool);
            
            // E?te viac "premie?ame" osudie tak, ?e nieko?ko prv?ch 
            // n��hodn?ch ?��sel ��plne zahod��me (tzv. RNG warm-up)
            for(int i = 0; i < (press_time % 10); i++) {
                rand(); 
            }

            // Hod��me kockou
            uint8_t final_result = play_roll_animation();
            
            // Uk��?eme v?sledok
            display_face(final_result, 2000); 
            
            // Pred sp��nkom resetneme vlajku
            button_pressed_flag = 0;
        }
    }
}